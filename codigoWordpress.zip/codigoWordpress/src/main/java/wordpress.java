/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jesus
 */
import java.io.BufferedReader;
import java.io.IOException;
public class wordpress {
    String nombre;
public static void main(String[] args) {
// Declaración de variables
Double x, y,z;
float a, b = 0, c;

BufredReader bufer = new BufferedReader(new ImputStreamReader());
String entrada;
System.out.println(&quot;Escribe el valor de x: &quot;);
entrada = bufer.readLine();
x= Integer.parseInt(entrada);
System.out.println(&quot;Escribe el valor de y: &quot;);
entrada = bufer.readLine();
y = Double.parseDouble(entrada);
z = y / x;
System.out.println(&quot;El residuo de dividir y ( + y + &quot;) entre x ( &quot; +x + ) es: &quot; + z);
System.out.println(&quot;Escribe el valor de a: &quot;);
entrada = b.readLine();
a = entrada;
System.out.println(&quot;Escribe el valor de b: &quot;);
in = bufer.readLine();
b = Float.parseFloat(entrada);
c = a * b ;
System.out.println(&quot;El resultado de multiplicar a por b es: &quot; + c);
}
}